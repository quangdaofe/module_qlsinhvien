<?php

/**
 * NukeViet Content Management System
 * @version 5.x
 * @author VINADES.,JSC <contact@vinades.vn>
 * @copyright (C) 2009-2025 VINADES.,JSC. All rights reserved
 * @license GNU/GPL version 2 or any later version
 * @see https://github.com/nukeviet The NukeViet CMS GitHub project
 */

use phpDocumentor\Reflection\Types\Null_;

if (!defined('NV_IS_FILE_ADMIN')) {
    exit('Stop!!!');
}
$data = array();
$id = $nv_Request->get_title('id', 'get', '');
if (!empty($id)) {
    $sql1 = 'SELECT * FROM ' . $db_config['prefix'] . '_' . $module_data . ' WHERE id=' . $_GET['id'];
    $result = $db->query($sql1);
    $data = $result->fetch();
}
$page_title = $nv_Lang->getModule('list');
$row = [];
if ($nv_Request->isset_request('save', 'post')) {
    $error = "";
    $row['fullname'] = nv_substr($nv_Request->get_title('fullname', 'post', ""), 0, 250);
    $row['birtday'] = $nv_Request->get_int('birtday', 'post', 0, 250);
    $row['address'] = nv_substr($nv_Request->get_title('address', 'post', ""), 0, 250);
    $row['phone_number'] = $nv_Request->get_int('phone_number', 'post', 0, 250);
    $row['email'] = nv_substr($nv_Request->get_title('email', 'post', ""), 0, 250);
    $row['gender'] = nv_substr($nv_Request->get_title('gender', 'post', ""), 0, 250);
    if (empty($row['fullname'])) {
        $error= $nv_Lang->getModule('Vui lòng nhập họ tên');
    }else if (empty($row['birtday'])) {
        $error= $nv_Lang->getModule('Vui lòng nhập ngày sinh');
        $data['fullname'] = $row['fullname'];
    }else if (empty($row['address'])) {
        $error= $nv_Lang->getModule('Vui lòng nhập địa chỉ');
        $data['fullname'] = $row['fullname'];
        $data['birtday'] = $row['birtday'];
    }else if (empty($row['gender'])) {
        $error= $nv_Lang->getModule('Vui lòng chọn giới tính');
        $data['fullname'] = $row['fullname'];
        $data['birtday'] = $row['birtday'];
        $data['address'] = $row['address'];
    }else if (empty($row['email'])) {
        $error= $nv_Lang->getModule('Vui lòng nhập email');
        $data['fullname'] = $row['fullname'];
        $data['birtday'] = $row['birtday'];
        $data['address'] = $row['address'];
        $data['gender'] = $row['gender'];

    }else if (($row['pone_number'])==="") {
        $error= $nv_Lang->getModule('Vui lòng nhập số điện thoại');
        $data['fullname'] = $row['fullname'];
        $data['birtday'] = $row['birtday'];
        $data['address'] = $row['address'];
        $data['gender'] = $row['gender'];
        $data['email'] = $row['email'];
        $data['phone_number'] = $row['phone_number'];
    }
    var_dump($data);
    if (empty($error)) {
        $table = $db_config['prefix'];
        if (isset($_GET["id"])) {
            $sql1 = 'SELECT * FROM ' . $table . '_' . $module_data . ' WHERE id=' . $_GET['id'];
            $result = $db->query($sql1);
            $data = $result->fetch();
            $row['fullname'] = nv_substr($nv_Request->get_title('fullname', 'post', ""), 0, 250);
            $row['birtday'] = $nv_Request->get_int('birtday', 'post', 0, 250);
            $row['address'] = nv_substr($nv_Request->get_title('address', 'post', ""), 0, 250);
            $row['phone_number'] = $nv_Request->get_int('phone_number', 'post', 0, 250);
            $row['email'] = nv_substr($nv_Request->get_title('email', 'post', ""), 0, 250);
            $row['gender'] = nv_substr($nv_Request->get_title('gender', 'post', ""), 0, 250);
            $sql = "UPDATE " . $table . '_' . $module_data . " SET " .
                "fullname=:fullname,birtday=:birtday,address=:address,phone_number=:phone_number,email=:email,gender=:gender
            WHERE `nv5_qlsinhvien`.`id` =" . $_GET["id"];
            $sth = $db->prepare($sql);
        } else {
            $row['fullname'] = nv_substr($nv_Request->get_title('fullname', 'post', ""), 0, 250);
            $row['birtday'] = $nv_Request->get_int('birtday', 'post', 0, 250);
            $row['address'] = nv_substr($nv_Request->get_title('address', 'post', ""), 0, 250);
            $row['phone_number'] = $nv_Request->get_int('phone_number', 'post', 0, 250);
            $row['email'] = nv_substr($nv_Request->get_title('email', 'post', ""), 0, 250);
            $row['gender'] = nv_substr($nv_Request->get_title('gender', 'post', ""), 0, 250);
            $sql = 'INSERT INTO ' . $table . '_' . $module_data . '(fullname,birtday,address,phone_number,email,gender)' .
                "VALUES (:fullname,:birtday,:address,:phone_number,:email,:gender)";
            $sth = $db->prepare($sql);
        }
            $sth->bindParam(':fullname', $row['fullname'], PDO::PARAM_STR);
            $sth->bindParam(':birtday', $row['birtday'], PDO::PARAM_INT);
            $sth->bindParam(':address', $row['address'], PDO::PARAM_STR);
            $sth->bindParam(':phone_number', $row['phone_number'], PDO::PARAM_INT);
            $sth->bindParam(':email', $row['email'], PDO::PARAM_STR);
            $sth->bindParam(':gender', $row['gender'], PDO::PARAM_STR);
            $exe = $sth->execute();
        if ($exe) {
            print_r(nv_redirect_location(NV_BASE_ADMINURL . 'index.php?' . NV_NAME_VARIABLE . '=' . $module_name));
        }
    }
}
$xtpl = new XTemplate('add.tpl', NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/modules/' . $module_file);
$xtpl->assign('LANG', \NukeViet\Core\Language::$lang_module);
$xtpl->assign('GLANG', \NukeViet\Core\Language::$lang_global);
//Hiện thị dữ liệu
if (!empty($data)) {
    $xtpl->assign('DATA', $data);
    $xtpl->parse('main.loop');
}
if (!empty($error)) {
    $xtpl->assign('ERROR', $error);
    $xtpl->parse('main.error');
}
$xtpl->parse('main');
$contents = $xtpl->text('main');

include NV_ROOTDIR . '/includes/header.php';
echo nv_admin_theme($contents);
include NV_ROOTDIR . '/includes/footer.php';
